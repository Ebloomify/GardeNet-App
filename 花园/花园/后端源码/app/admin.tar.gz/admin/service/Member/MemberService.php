<?php 
/*
 module:		会员列表
 create_time:	2022-01-18 00:20:02
 author:		
 contact:		
*/

namespace app\admin\service\Member;
use app\admin\model\Member\Member;
use think\exception\ValidateException;
use xhadmin\CommonService;

class MemberService extends CommonService {


	/*
 	* @Description  列表数据
 	*/
	public static function indexList($where,$field,$order,$limit,$page){
		try{
			$res = Member::where($where)->field($field)->order($order)->paginate(['list_rows'=>$limit,'page'=>$page])->toArray();
		}catch(\Exception $e){
			abort(config('my.error_log_code'),$e->getMessage());
		}
		return ['rows'=>$res['data'],'total'=>$res['total']];
	}


	/*
 	* @Description  添加
 	*/
	public static function add($data){
		try{
			validate(\app\admin\validate\Member\Member::class)->scene('add')->check($data);
			$data['password'] = md5($data['password'].config('my.password_secrect'));
			$data['create_time'] = strtotime($data['create_time']);
			$res = Member::create($data);
		}catch(ValidateException $e){
			throw new ValidateException ($e->getError());
		}catch(\Exception $e){
			abort(config('my.error_log_code'),$e->getMessage());
		}
		if(!$res){
			throw new ValidateException ('操作失败');
		}
		return $res->member_id;
	}


	/*
 	* @Description  修改
 	*/
	public static function update($data){
		try{
			validate(\app\admin\validate\Member\Member::class)->scene('update')->check($data);
			$member = Member::where('member_id',$data['member_id'])->find();
			if($data['integral']>$member['integral']){
                \db('integer_log')->insert([
                    'member_id'=>$member['member_id'],'integer'=>$data['integral']-$member['integral'],'type'=>2,'create_time'=>time()
                ]);
            }
			$data['create_time'] = strtotime($data['create_time']);
			$res = Member::update($data);
		}catch(ValidateException $e){
			throw new ValidateException ($e->getError());
		}catch(\Exception $e){
			abort(config('my.error_log_code'),$e->getMessage());
		}
		if(!$res){
			throw new ValidateException ('操作失败');
		}
		return $res;
	}


	/*
 	* @Description  修改密码
 	*/
	public static function uppass($data){
		try{
			validate(\app\admin\validate\Member\Member::class)->scene('uppass')->check($data);
			$data['password'] = md5($data['password'].config('my.password_secrect'));
			$res = Member::update($data);
		}catch(ValidateException $e){
			throw new ValidateException ($e->getError());
		}catch(\Exception $e){
			abort(config('my.error_log_code'),$e->getMessage());
		}
		return $res;
	}




}

