<?php 
namespace app\admin\model\Cms;
use think\Model;

class Position extends Model {


	protected $pk = 'position_id';

 	protected $name = 'position';
 

}

