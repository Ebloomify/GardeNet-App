<?php 
namespace app\ApplicationName\model;
use think\Model;

class Content extends Model {


	protected $pk = 'content_id';

 	protected $name = 'content';
 

}

