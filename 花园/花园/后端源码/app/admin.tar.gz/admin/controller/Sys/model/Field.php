<?php
namespace app\admin\controller\Sys\model;

use think\Model;

class Field extends Model
{
	
	protected $pk = 'id';
	
	
}