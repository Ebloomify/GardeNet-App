<?php
namespace app\admin\controller\Sys\model;

use think\Model;

class Menu extends Model
{
	
	protected $pk = 'menu_id';
	
	
}