<?php 
namespace app\ApplicationName\model;
use think\Model;

class Catagory extends Model {


	protected $pk = 'class_id';

 	protected $name = 'catagory';
 

}

