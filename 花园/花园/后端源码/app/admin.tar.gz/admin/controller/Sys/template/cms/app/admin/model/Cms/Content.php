<?php 
namespace app\admin\model\Cms;
use think\Model;

class Content extends Model {


	protected $pk = 'content_id';

 	protected $name = 'content';
 

}

