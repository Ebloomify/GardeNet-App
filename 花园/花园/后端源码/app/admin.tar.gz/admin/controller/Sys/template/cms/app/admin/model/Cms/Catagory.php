<?php 
namespace app\admin\model\Cms;
use think\Model;

class Catagory extends Model {


	protected $pk = 'class_id';

 	protected $name = 'catagory';
 

}

