<?php 
namespace app\admin\model\Cms;
use think\Model;

class Frament extends Model {


	protected $pk = 'frament_id';

 	protected $name = 'frament';
 

}

