<?php 
/*
 module:		用户管理模型
 create_time:	2021-07-07 13:07:02
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class User extends Model {


	protected $pk = 'user_id';

 	protected $name = 'user';
 

}

