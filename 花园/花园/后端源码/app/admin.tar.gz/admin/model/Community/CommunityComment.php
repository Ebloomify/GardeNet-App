<?php 
/*
 module:		评论管理模型
 create_time:	2022-01-16 23:30:19
 author:		
 contact:		
*/

namespace app\admin\model\Community;
use think\Model;

class CommunityComment extends Model {


	protected $pk = 'community_comment_id';

 	protected $name = 'community_comment';
 

}

