<?php 
/*
 module:		文章管理模型
 create_time:	2022-01-18 00:22:33
 author:		
 contact:		
*/

namespace app\admin\model\Community;
use think\Model;

class CommunityArticle extends Model {


	protected $pk = 'community_article_id';

 	protected $name = 'community_article';
 

}

