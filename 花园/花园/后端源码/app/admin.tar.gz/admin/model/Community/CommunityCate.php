<?php 
/*
 module:		分类管理模型
 create_time:	2022-01-16 12:24:51
 author:		
 contact:		
*/

namespace app\admin\model\Community;
use think\Model;

class CommunityCate extends Model {


	protected $pk = 'community_cate_id';

 	protected $name = 'community_cate';
 

}

