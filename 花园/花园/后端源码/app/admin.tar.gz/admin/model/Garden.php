<?php 
/*
 module:		花园列表模型
 create_time:	2022-01-16 19:46:31
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Garden extends Model {


	protected $pk = 'id';

 	protected $name = 'garden';
 

}

