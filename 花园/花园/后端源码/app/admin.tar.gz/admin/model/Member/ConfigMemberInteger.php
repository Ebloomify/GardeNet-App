<?php 
/*
 module:		会员积分等级设置模型
 create_time:	2021-07-09 13:18:43
 author:		
 contact:		
*/

namespace app\admin\model\Member;
use think\Model;

class ConfigMemberInteger extends Model {


	protected $pk = 'config_member_integer_id';

 	protected $name = 'config_member_integer';
 

}

