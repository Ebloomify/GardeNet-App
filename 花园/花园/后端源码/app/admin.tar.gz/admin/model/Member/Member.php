<?php 
/*
 module:		会员列表模型
 create_time:	2022-01-18 00:20:02
 author:		
 contact:		
*/

namespace app\admin\model\Member;
use think\Model;

class Member extends Model {


	protected $pk = 'member_id';

 	protected $name = 'member';
 

}

