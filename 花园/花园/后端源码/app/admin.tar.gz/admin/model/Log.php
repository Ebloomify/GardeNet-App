<?php 
/*
 module:		日志管理模型
 create_time:	2021-01-05 14:47:06
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Log extends Model {


	protected $pk = 'id';

 	protected $name = 'log';
 

}

