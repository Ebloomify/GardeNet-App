<?php 
/*
 module:		积分任务设置模型
 create_time:	2021-08-03 09:51:27
 author:		
 contact:		
*/

namespace app\admin\model\Integer;
use think\Model;

class ConfigInteger extends Model {


	protected $pk = 'config_integer_id';

 	protected $name = 'config_integer';
 

}

