<?php 
/*
 module:		会员积分等级设置模型
 create_time:	2021-07-09 13:21:53
 author:		
 contact:		
*/

namespace app\admin\model\Integer;
use think\Model;

class ConfigMemberInteger extends Model {


	protected $pk = 'config_member_integer_id';

 	protected $name = 'config_member_integer';
 

}

