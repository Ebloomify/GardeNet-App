<?php 
/*
 module:		角色管理模型
 create_time:	2021-07-07 13:07:05
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Role extends Model {


	protected $pk = 'role_id';

 	protected $name = 'role';
 

}

