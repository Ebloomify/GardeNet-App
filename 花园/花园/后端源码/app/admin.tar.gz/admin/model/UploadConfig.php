<?php 
/*
 module:		上传配置模型
 create_time:	2021-01-05 14:47:09
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class UploadConfig extends Model {


	protected $pk = 'id';

 	protected $name = 'upload_config';
 

}

