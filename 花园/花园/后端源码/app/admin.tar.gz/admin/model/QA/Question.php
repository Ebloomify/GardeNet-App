<?php 
/*
 module:		问题列表模型
 create_time:	2022-01-16 23:36:37
 author:		
 contact:		
*/

namespace app\admin\model\QA;
use think\Model;

class Question extends Model {


	protected $pk = 'question_id';

 	protected $name = 'question';
 

}

