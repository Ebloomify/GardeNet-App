<?php 
/*
 module:		回答列表模型
 create_time:	2022-01-16 23:38:57
 author:		
 contact:		
*/

namespace app\admin\model\QA;
use think\Model;

class QuestionAnswer extends Model {


	protected $pk = 'question_answer_id';

 	protected $name = 'question_answer';
 

}

