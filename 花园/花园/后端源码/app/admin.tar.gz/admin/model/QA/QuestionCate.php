<?php 
/*
 module:		分类管理模型
 create_time:	2022-01-16 13:01:20
 author:		
 contact:		
*/

namespace app\admin\model\QA;
use think\Model;

class QuestionCate extends Model {


	protected $pk = 'question_cate_id';

 	protected $name = 'question_cate';
 

}

