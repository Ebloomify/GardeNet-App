<?php 
/*
 module:		反馈列表模型
 create_time:	2021-11-13 23:22:44
 author:		
 contact:		
*/

namespace app\admin\model\Feedback;
use think\Model;

class Index extends Model {


	protected $pk = 'feedback_id';

 	protected $name = 'feedback';
 

}

