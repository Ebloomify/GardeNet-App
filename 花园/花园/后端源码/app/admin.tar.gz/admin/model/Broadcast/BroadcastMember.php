<?php 
/*
 module:		广播用户历史记录模型
 create_time:	2021-12-19 20:18:55
 author:		
 contact:		
*/

namespace app\admin\model\Broadcast;
use think\Model;

class BroadcastMember extends Model {


	protected $pk = 'broadcast_member_id';

 	protected $name = 'broadcast_member';
 

}

