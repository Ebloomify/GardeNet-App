<?php 
/*
 module:		公告管理模型
 create_time:	2021-08-03 09:25:29
 author:		
 contact:		
*/

namespace app\admin\model\Broadcast;
use think\Model;

class Broadcast extends Model {


	protected $pk = 'broadcast_id';

 	protected $name = 'broadcast';
 

}

