<?php 
/*
 module:		评论管理模型
 create_time:	2022-01-16 23:21:03
 author:		
 contact:		
*/

namespace app\admin\model\Discover;
use think\Model;

class DiscoverComment extends Model {


	protected $pk = 'discover_comment_id';

 	protected $name = 'discover_comment';
 

}

