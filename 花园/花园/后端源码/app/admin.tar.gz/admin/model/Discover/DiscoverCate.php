<?php 
/*
 module:		分类管理模型
 create_time:	2022-01-16 12:13:35
 author:		
 contact:		
*/

namespace app\admin\model\Discover;
use think\Model;

class DiscoverCate extends Model {


	protected $pk = 'discover_cate_id';

 	protected $name = 'discover_cate';
 

}

