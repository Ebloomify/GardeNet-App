<?php 
/*
 module:		文章管理模型
 create_time:	2022-01-16 23:01:32
 author:		
 contact:		
*/

namespace app\admin\model\Discover;
use think\Model;

class DiscoverArticle extends Model {


	protected $pk = 'discover_article_id';

 	protected $name = 'discover_article';
 

}

