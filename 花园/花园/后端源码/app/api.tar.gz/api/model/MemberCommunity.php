<?php 
/*
 module:		我的Community模型
 create_time:	2021-12-19 19:14:18
 author:		
 contact:		
*/

namespace app\api\model;
use think\Model;

class MemberCommunity extends Model {


	protected $pk = 'community';

 	protected $name = 'community';
 

}

