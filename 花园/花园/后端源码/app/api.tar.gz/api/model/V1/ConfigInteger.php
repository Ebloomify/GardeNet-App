<?php 
/*
 module:		会员积分记录模型
 create_time:	2021-11-16 04:26:51
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class ConfigInteger extends Model {


	protected $pk = 'config_integer_id';

 	protected $name = 'config_integer';
 

}

