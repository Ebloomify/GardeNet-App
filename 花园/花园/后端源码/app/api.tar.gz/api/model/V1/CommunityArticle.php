<?php 
/*
 module:		Community模型
 create_time:	2021-07-12 13:50:05
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class CommunityArticle extends Model {


	protected $pk = 'community_article_id';

 	protected $name = 'community_article';
 

}

