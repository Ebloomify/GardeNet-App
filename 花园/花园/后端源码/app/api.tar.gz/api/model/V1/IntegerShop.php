<?php 
/*
 module:		积分商城模型
 create_time:	2021-11-16 17:38:54
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class IntegerShop extends Model {


	protected $pk = '';

 	protected $name = '';
 

}

