<?php 
/*
 module:		会员积分记录模型
 create_time:	2021-11-16 04:26:51
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class MemberIntegral extends Model {


	protected $pk = 'member_integral_id';

 	protected $name = 'member_integral';
 

}

