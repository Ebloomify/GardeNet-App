<?php
declare (strict_types = 1);

namespace app\api\model\V1;

use think\Model;

/**
 * @mixin \think\Model
 */
class Remind extends Model
{
    //
}
