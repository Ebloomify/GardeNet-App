<?php 
/*
 module:		Community分类模型
 create_time:	2021-07-09 18:46:52
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class CommunityCate extends Model {


	protected $pk = 'community_cate_id';

 	protected $name = 'community_cate';
 

}

