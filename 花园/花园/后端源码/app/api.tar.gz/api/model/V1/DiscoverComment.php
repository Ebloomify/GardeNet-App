<?php 
/*
 module:		Discover评论模型
 create_time:	2021-07-12 14:10:17
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class DiscoverComment extends Model {


	protected $pk = 'discover_comment_id';

 	protected $name = 'discover_comment';
 

}

