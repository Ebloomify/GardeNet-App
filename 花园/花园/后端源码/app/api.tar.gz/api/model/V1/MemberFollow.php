<?php 
/*
 module:		会员关注关系模型
 create_time:	2021-07-12 12:47:58
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class MemberFollow extends Model {


	protected $pk = 'member_follow_id';

 	protected $name = 'member_follow';
 

}

