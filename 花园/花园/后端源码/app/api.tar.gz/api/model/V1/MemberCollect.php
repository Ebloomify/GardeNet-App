<?php 
/*
 module:		会员收藏模型
 create_time:	2021-11-14 04:38:55
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class MemberCollect extends Model {


	protected $pk = 'member_collect_id';

 	protected $name = 'member_collect';
 

}

