<?php 
/*
 module:		花园模型
 create_time:	2021-12-23 23:46:57
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class Garden extends Model {


	protected $pk = 'id';

 	protected $name = 'garden';
 

}

