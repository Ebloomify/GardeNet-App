<?php 
/*
 module:		QA问题模型
 create_time:	2021-08-05 10:14:53
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class Question extends Model {


	protected $pk = 'question_id';

 	protected $name = 'question';
 

}

