<?php 
/*
 module:		Discover分类模型
 create_time:	2021-07-09 18:15:50
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class DiscoverCate extends Model {


	protected $pk = 'discover_cate_id';

 	protected $name = 'discover_cate';
 

}

