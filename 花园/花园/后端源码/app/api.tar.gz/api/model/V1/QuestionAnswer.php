<?php 
/*
 module:		QA问题_回答模型
 create_time:	2021-11-17 00:32:52
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class QuestionAnswer extends Model {


	protected $pk = 'question_answer_id';

 	protected $name = 'question_answer';
 

}

