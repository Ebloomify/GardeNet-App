<?php 
/*
 module:		消息模型
 create_time:	2021-11-17 01:38:26
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class Notification extends Model {


	protected $pk = '';

 	protected $name = '';
 

}

