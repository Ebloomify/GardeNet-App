<?php 
/*
 module:		我的Community模型
 create_time:	2021-12-19 19:27:53
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class MemberCommunity extends Model {


	protected $pk = 'community_comment_id';

 	protected $name = 'community_comment';
 

}

