<?php 
/*
 module:		Community模型
 create_time:	2021-07-12 13:50:05
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class BroadcastMember extends Model {


	protected $pk = 'broadcast_member_id';

 	protected $name = 'broadcast_member';
 

}

