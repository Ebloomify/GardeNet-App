<?php 
/*
 module:		Discover模型
 create_time:	2021-07-09 18:19:17
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class DiscoverArticle extends Model {


	protected $pk = 'discover_article_id';

 	protected $name = 'discover_article';
 

}

