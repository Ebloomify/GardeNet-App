<?php 
/*
 module:		Community评论模型
 create_time:	2021-07-12 14:21:14
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class CommunityComment extends Model {


	protected $pk = 'community_comment_id';

 	protected $name = 'community_comment';
 

}

