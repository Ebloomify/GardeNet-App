<?php 
/*
 module:		会员点赞模型
 create_time:	2021-07-12 12:04:02
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class MemberLike extends Model {


	protected $pk = 'member_like_id';

 	protected $name = 'member_like';
 

}

