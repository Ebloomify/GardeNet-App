<?php 
/*
 module:		我的分享模型
 create_time:	2021-11-16 17:26:57
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class MemberShare extends Model {


	protected $pk = 'member_share_id';

 	protected $name = 'member_share';
 

}

