<?php 
/*
 module:		增减积分模型
 create_time:	2021-11-16 16:57:40
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class PlusMinusInteger extends Model {


	protected $pk = '';

 	protected $name = '';
 

}

