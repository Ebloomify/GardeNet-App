<?php 
/*
 module:		会员列表模型
 create_time:	2021-12-19 19:57:51
 author:		
 contact:		
*/

namespace app\api\model\V1;
use think\Model;

class Member extends Model {


	protected $pk = 'member_id';

 	protected $name = 'member';
 

}

