<?php 
/*
 module:		意见反馈模型
 create_time:	2021-11-16 01:09:00
 author:		
 contact:		
*/

namespace app\api\model;
use think\Model;

class Feedback extends Model {


	protected $pk = '';

 	protected $name = 'feedback';
 

}

