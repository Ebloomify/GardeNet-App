<?php 
/*
 module:		花园模型
 create_time:	2021-12-19 23:06:32
 author:		
 contact:		
*/

namespace app\api\model;
use think\Model;

class Garden extends Model {


	protected $pk = 'id';

 	protected $name = 'garden';
 

}

