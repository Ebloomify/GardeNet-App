<?php 
/*
 module:		基础信息模型
 create_time:	2021-11-16 00:49:37
 author:		
 contact:		
*/

namespace app\api\model;
use think\Model;

class Config extends Model {


	protected $pk = '';

 	protected $name = 'config';
 

}

