<?php 
/*
 module:		会员积分说明模型
 create_time:	2021-11-16 01:38:35
 author:		
 contact:		
*/

namespace app\api\model;
use think\Model;

class ConfigMemberInteger extends Model {


	protected $pk = '';

 	protected $name = 'config_member_integer';
 

}

