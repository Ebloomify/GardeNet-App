<?php 
/*
 module:		消息
 create_time:	2021-11-17 01:38:26
 author:		
 contact:		
*/

namespace app\api\service\V1;
use think\facade\Log;
use think\exception\ValidateException;
use xhadmin\CommonService;

class NotificationService extends CommonService {




}

