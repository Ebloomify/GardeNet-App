<?php 
/*
 module:		我的分享
 create_time:	2021-11-16 17:26:57
 author:		
 contact:		
*/

namespace app\api\service\V1;
use app\api\model\V1\MemberShare;
use think\facade\Log;
use think\exception\ValidateException;
use xhadmin\CommonService;

class MemberShareService extends CommonService {




}

