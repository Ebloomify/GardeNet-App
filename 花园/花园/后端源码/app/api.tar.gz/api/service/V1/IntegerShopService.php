<?php 
/*
 module:		积分商城
 create_time:	2021-11-16 17:38:54
 author:		
 contact:		
*/

namespace app\api\service\V1;
use think\facade\Log;
use think\exception\ValidateException;
use xhadmin\CommonService;

class IntegerShopService extends CommonService {




}

