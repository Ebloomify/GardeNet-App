<?php
/*
 module:		会员关注关系
 create_time:	2021-07-12 12:47:58
 author:		
 contact:		
*/

namespace app\api\controller\V1;

use app\api\service\V1\MemberFollowService;
use app\api\model\V1\MemberFollow as MemberFollowModel;
use app\api\controller\Common;
use think\exception\ValidateException;
use think\facade\Db;
use think\facade\Log;

class MemberFollow extends Common
{

    /*start*/
    /**
     * @api {get} /V1.MemberFollow/index 01、首页数据列表
     * @apiGroup MemberFollow
     * @apiVersion 1.0.0
     * @apiDescription  首页数据列表
     * @apiParam (输入参数：) {int}            [limit] 每页数据条数（默认20）
     * @apiParam (输入参数：) {int}            [page] 当前页码
     * @apiParam (输入参数：) {int}            [fans] 1 我的关注 0我的粉丝
     * @apiParam (输入参数：) {int}            [search] 搜索
     * @apiHeader {String} Authorization 用户授权token
     * @apiHeaderExample {json} Header-示例:
     * "Authorization: eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOjM2NzgsImF1ZGllbmNlIjoid2ViIiwib3BlbkFJZCI6MTM2NywiY3JlYXRlZCI6MTUzMzg3OTM2ODA0Nywicm9sZXMiOiJVU0VSIiwiZXhwIjoxNTM0NDg0MTY4fQ.Gl5L-NpuwhjuPXFuhPax8ak5c64skjDTCBC64N_QdKQ2VT-zZeceuzXB9TqaYJuhkwNYEhrV3pUx1zhMWG7Org"

     * @apiParam (失败返回参数：) {object}        array 返回结果集
     * @apiParam (失败返回参数：) {string}        array.status 返回错误码 201
     * @apiParam (失败返回参数：) {string}        array.msg 返回错误消息
     * @apiParam (成功返回参数：) {string}        array 返回结果集
     * @apiParam (成功返回参数：) {string}        array.status 返回错误码 200
     * @apiParam (成功返回参数：) {string}        array.data 返回数据
     * @apiParam (成功返回参数：) {string}        array.data.list 返回数据列表
     * @apiParam (成功返回参数：) {string}        array.data.count 返回数据总数
     * @apiSuccessExample {json} 01 成功示例
     * {"status":"200","data":""}
     * @apiErrorExample {json} 02 失败示例
     * {"status":" 201","msg":"查询失败"}
     */
    function index()
    {
        $limit = $this->request->post('limit', 20, 'intval');
        $page = $this->request->post('page', 1, 'intval');
        $fans = $this->request->post('fans');
        $search = $this->request->post('search');
        $where = [];
        if ($this->request->uid) {
            $member_id = $this->request->uid;
        } else {
            $member_id = 0;
        }
        if ($fans == 1) {
            $where['follow_member_id'] = $member_id;
        }else{
            $where['member_id'] = $member_id;
        }

        if ($search = $this->request->post('search', '')) {
            if ($member = \app\api\model\V1\Member::where('nickname', 'like', '%' . $search . '%')
                ->field('member_id')->find()) {
                $where['member_id'] = $member['member_id'];
            }
        }

        $field = '*';
        $orderby = 'member_follow_id desc';

        $res = MemberFollowService::indexList(formatWhere($where), $field, $orderby, $limit, $page);
        return $this->ajaxReturn($this->successCode, '返回成功', htmlOutList($res));
    }
    /*end*/

    /*start*/
    /**
     * @api {post} /V1.MemberFollow/addAndRemove 02、关注or取消关注用户
     * @apiGroup MemberFollow
     * @apiVersion 1.0.0
     * @apiDescription  添加
     * @apiHeader {String} Authorization 用户授权token
     * @apiHeaderExample {json} Header-示例:
     * "Authorization: eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOjM2NzgsImF1ZGllbmNlIjoid2ViIiwib3BlbkFJZCI6MTM2NywiY3JlYXRlZCI6MTUzMzg3OTM2ODA0Nywicm9sZXMiOiJVU0VSIiwiZXhwIjoxNTM0NDg0MTY4fQ.Gl5L-NpuwhjuPXFuhPax8ak5c64skjDTCBC64N_QdKQ2VT-zZeceuzXB9TqaYJuhkwNYEhrV3pUx1zhMWG7Org"
     * @apiParam (输入参数：) {int}                follow_member_id 关注对象id
     * @apiSuccessExample {json} 01 成功示例
     * {"status":"200","data":"操作成功"}
     * @apiErrorExample {json} 02 失败示例
     * {"status":" 201","msg":"操作失败"}
     */
    function addAndRemove()
    {
        $postField = 'follow_member_id';
        $data = $this->request->only(explode(',', $postField), 'post', null);

        $followMember = \app\api\model\V1\Member::find($data['follow_member_id']);
        if (!$followMember) return $this->ajaxReturn($this->errorCode, '关注用户不存在');

        //是否存在关注记录  存在则取消 不存在则新增

        $isExists = MemberFollowModel::where([
            'member_id' => $this->request->uid,
            'follow_member_id' => $data['follow_member_id'],
        ])->find();

        if ($isExists) { //取消关注
            if ($isExists['all_follow'] == 1) {
                MemberFollowModel::where([
                    'follow_member_id' => $this->request->uid,
                    'member_id' => $data['follow_member_id'],
                ])->update(['all_follow' => 0]);
            }
            $isExists->delete();
            $msg = '取消关注成功';
        } else { //新增关注
            $insert = [];
            $follows = MemberFollowModel::where([
                'follow_member_id' => $this->request->uid,
                'member_id' => $data['follow_member_id'],
            ])->find();
            if ($follows) {
                $follows->save(['all_follow' => 1]);
                $insert['all_follow'] = 1;
            }
            $insert['member_id'] = $this->request->uid;
            $insert['follow_member_id'] = $data['follow_member_id'];
            $insert['create_time'] = time();
            MemberFollowModel::insert($insert);

            $msg = '关注成功';
        }
        return $this->ajaxReturn($this->successCode, $msg);
    }
    /*end*/


}

