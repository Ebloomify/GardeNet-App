<?php
/*
 module:		消息
 create_time:	2021-11-17 01:38:26
 author:		
 contact:		
*/

namespace app\api\controller\V1;

use app\api\service\V1\NotificationService;
use app\api\controller\Common;
use think\exception\ValidateException;
use think\facade\Db;
use think\facade\Log;

class Notification extends Common
{

    /*start*/
    /**
     * @api {get} /V1.Notification/read 03、读消息
     * @apiGroup Notification
     * @apiVersion 1.0.0
     * @apiDescription  编辑数据
     * @apiParam (输入参数：) {string}            id 主键ID (必填)
     * @apiParam (输入参数：) {string}            type 文章类型 (必填 1 community 2 qa)
     * @apiHeader {String} Authorization 用户授权token
     * @apiHeaderExample {json} Header-示例:
     * "Authorization: eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOjM2NzgsImF1ZGllbmNlIjoid2ViIiwib3BlbkFJZCI6MTM2NywiY3JlYXRlZCI6MTUzMzg3OTM2ODA0Nywicm9sZXMiOiJVU0VSIiwiZXhwIjoxNTM0NDg0MTY4fQ.Gl5L-NpuwhjuPXFuhPax8ak5c64skjDTCBC64N_QdKQ2VT-zZeceuzXB9TqaYJuhkwNYEhrV3pUx1zhMWG7Org"
     * @apiParam (失败返回参数：) {object}        array 返回结果集
     * @apiParam (失败返回参数：) {string}        array.status 返回错误码  201
     * @apiParam (失败返回参数：) {string}        array.msg 返回错误消息
     * @apiParam (成功返回参数：) {string}        array 返回结果集
     * @apiParam (成功返回参数：) {string}        array.status 返回错误码 200
     * @apiParam (成功返回参数：) {string}        array.msg 返回成功消息
     * @apiSuccessExample {json} 01 成功示例
     * {"status":"200","msg":"操作成功"}
     * @apiErrorExample {json} 02 失败示例
     * {"status":" 201","msg":"操作失败"}
     */
    function read()
    {
        $postField = 'id,type';
        $data = $this->request->only(explode(',', $postField), 'get', null);
        if (!array_key_exists('type', $data))
            return $this->ajaxReturn($this->errorCode, '参数丢失');
        if (!array_key_exists('id', $data))
            return $this->ajaxReturn($this->errorCode, '参数丢失');
        if (!$member_id = $this->request->uid)
            return $this->ajaxReturn($this->errorCode, '请登录后重试');
        //type=1 community
        if ($data['type'] == 1) {
            \app\api\model\V1\CommunityComment::where('community_comment_id', $data['id'])
                ->where('member_id', $member_id)->update(['is_read' => 1]);

        } else {
            \app\api\model\V1\QuestionAnswer::where('question_answer_id', $data['id'])
                ->where('member_id', $member_id)->update(['is_read' => 1]);
        }

        return $this->ajaxReturn($this->successCode, '操作成功');
    }
    /*end*/

    /*start*/
    /**
     * @api {get} /V1.Notification/articleNotification 02、文章消息
     * @apiGroup Notification
     * @apiVersion 1.0.0
     * @apiDescription  文章消息
     * @apiHeader {String} Authorization 用户授权token
     * @apiHeaderExample {json} Header-示例:
     * "Authorization: eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOjM2NzgsImF1ZGllbmNlIjoid2ViIiwib3BlbkFJZCI6MTM2NywiY3JlYXRlZCI6MTUzMzg3OTM2ODA0Nywicm9sZXMiOiJVU0VSIiwiZXhwIjoxNTM0NDg0MTY4fQ.Gl5L-NpuwhjuPXFuhPax8ak5c64skjDTCBC64N_QdKQ2VT-zZeceuzXB9TqaYJuhkwNYEhrV3pUx1zhMWG7Org"
     * @apiParam (输入参数：) {int}            [limit] 每页数据条数（默认10,会×2）
     * @apiParam (输入参数：) {int}            [page] 当前页码
     * @apiParam (失败返回参数：) {object}        array 返回结果集
     * @apiParam (失败返回参数：) {string}        array.status 返回错误码 201
     * @apiParam (失败返回参数：) {string}        array.msg 返回错误消息
     * @apiParam (成功返回参数：) {string}        array 返回结果集
     * @apiParam (成功返回参数：) {string}        array.status 返回错误码 200
     * @apiParam (成功返回参数：) {string}        array.data 返回数据
     * @apiParam (成功返回参数：) {string}        array.data.list 返回数据列表
     * @apiParam (成功返回参数：) {string}        array.data.count 返回数据总数
     * @apiSuccessExample {json} 01 成功示例
     * {"status":"200","data":""}
     * @apiErrorExample {json} 02 失败示例
     * {"status":" 201","msg":"查询失败"}
     */
    function articleNotification()
    {
        $limit = $this->request->get('limit', 10, 'intval');
        $page = $this->request->get('page', 1, 'intval');
        if (!$member_id = $this->request->uid)
            return $this->ajaxReturn($this->errorCode, '请登录后重试');

        $community_comment = \app\api\model\V1\CommunityComment::where('to_member_id', $member_id)
            ->alias('c')->join('member m', 'm.member_id=c.member_id')
            ->join('community_article q', 'q.community_article_id=c.community_article_id')
            ->field('community_comment_id as id,c.member_id,c.community_article_id as article_id,q.title,c.create_time,c.content,m.nickname,m.avatar,c.is_read,1 as type')
            ->order('is_read', 'asc')->order('c.create_time', 'desc')
            ->paginate(['list_rows' => $limit, 'page' => $page])->toArray();

        $qa_comment = \app\api\model\V1\QuestionAnswer::where('to_member_id', $member_id)
            ->alias('c')->join('member m', 'm.member_id=c.member_id')
            ->join('question q', 'q.question_id=c.question_id')
            ->field('question_answer_id as id,c.member_id,c.question_id as article_id,q.title,c.create_time,c.content,m.nickname,m.avatar,c.is_read,2 as type')
            ->order('is_read', 'asc')->order('create_time', 'desc')
            ->paginate(['list_rows' => $limit, 'page' => $page])->toArray();

        //头像 昵称时间 文章标题 消息维度 评论内容 回复评论按钮
        //合并数据
        $res = array_merge($community_comment['data'], $qa_comment['data']);
        //重新排序
        array_multisort(array_column($res, 'create_time'), SORT_DESC, $res);

        $res = [
            'list' => $res,
            'count' => $qa_comment['total'] + $community_comment['total']
        ];

        return $this->ajaxReturn($this->successCode, '返回成功', htmlOutList($res));
    }
    /*end*/

    /*start*/
    /**
     * @api {get} /V1.Notification/systemNotification 01、系统消息
     * @apiGroup Notification
     * @apiVersion 1.0.0
     * @apiDescription  系统消息
     * @apiHeader {String} Authorization 用户授权token
     * @apiHeaderExample {json} Header-示例:
     * "Authorization: eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOjM2NzgsImF1ZGllbmNlIjoid2ViIiwib3BlbkFJZCI6MTM2NywiY3JlYXRlZCI6MTUzMzg3OTM2ODA0Nywicm9sZXMiOiJVU0VSIiwiZXhwIjoxNTM0NDg0MTY4fQ.Gl5L-NpuwhjuPXFuhPax8ak5c64skjDTCBC64N_QdKQ2VT-zZeceuzXB9TqaYJuhkwNYEhrV3pUx1zhMWG7Org"
     * @apiParam (输入参数：) {int}            [limit] 每页数据条数（默认20）
     * @apiParam (输入参数：) {int}            [page] 当前页码
     * @apiParam (失败返回参数：) {object}        array 返回结果集
     * @apiParam (失败返回参数：) {string}        array.status 返回错误码 201
     * @apiParam (失败返回参数：) {string}        array.msg 返回错误消息
     * @apiParam (成功返回参数：) {string}        array 返回结果集
     * @apiParam (成功返回参数：) {string}        array.status 返回错误码 200
     * @apiParam (成功返回参数：) {string}        array.data 返回数据
     * @apiParam (成功返回参数：) {string}        array.data.list 返回数据列表
     * @apiParam (成功返回参数：) {string}        array.data.count 返回数据总数
     * @apiSuccessExample {json} 01 成功示例
     * {"status":"200","data":""}
     * @apiErrorExample {json} 02 失败示例
     * {"status":" 201","msg":"查询失败"}
     */
    function systemNotification()
    {
        $limit = $this->request->get('limit', 20, 'intval');
        $page = $this->request->get('page', 1, 'intval');

        if (!$member_id = $this->request->uid)
            return $this->ajaxReturn($this->errorCode, '请登录后重试');
        $broadcast_member = BroadcastMember::where('member_id', $member_id)->column('broadcast_id');
        $broadcast_member_str = implode(',', $broadcast_member);
        $broadcast_member_str = $broadcast_member_str ? $broadcast_member_str : 0;

        $res = Broadcast::where('to_member_id', 0)->whereOr('to_member_id', $member_id)
            ->orderRaw("field(broadcast_id,$broadcast_member_str) asc")->order('create_time', 'desc')
            ->paginate(['list_rows' => $limit, 'page' => $page])->toArray();
        foreach ($res['data'] as $k => $v) {
            $res['data'][$k]['is_read'] = 0;
            foreach ($broadcast_member as $vv) {
                if ($vv == $v['broadcast_id']) {
                    $res['data'][$k]['is_read'] = 1;
                }
            }
        }
        $data = ['list' => $res['data'], 'count' => $res['total']];
        return $this->ajaxReturn($this->successCode, '返回成功', htmlOutList($data));
    }
    /*end*/


}

